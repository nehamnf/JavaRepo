package com.myrepo.springcoredemo.common;

public interface Coach {

    public String getDailyWorkout();
}
