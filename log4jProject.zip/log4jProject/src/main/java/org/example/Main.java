package org.example;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.module1.Module1Class;
import org.example.module2.Module2Class;

public class Main {
    private static final Logger logger = LogManager.getLogger( Main.class);

//    private static final Logger logger1 = LogManager.getLogger("com.example.module1");
//    private static final Logger logger2 = LogManager.getLogger("com.example.module2");

    public static void main(String[] args) {
        System.setProperty("log4j.configurationFile", "C:\\Users\\NehaMN\\IdeaProjects\\JavaRepo\\log4jProject\\src\\main\\resources\\log4j2-module1.xml");
        Module1Class module1 = new Module1Class();
        module1.performAction();

//        logger1.debug("Debug message for Module 1");
//        logger2.debug("Debug message for Module 2");

        // Set up logging configuration for Module 2
        System.setProperty("log4j.configurationFile", "C:\\Users\\NehaMN\\IdeaProjects\\JavaRepo\\log4jProject\\src\\main\\resources\\log4j2-module1.xml");
        Module2Class module2 = new Module2Class();
        module2.performAction();

        logger.info("from main class");
    }
}